package com.vzw.cst.job.simplejdbc;

import java.util.List;

import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemWriter;
import org.springframework.stereotype.Component;

import com.vzw.cst.common.CustList;


@StepScope
@Component
public class FutureOrderItemWriter implements ItemWriter<Object> {

	@Override
	public void write(List<? extends Object> items) throws Exception {
		for (Object item : items) {
			CustList payload = (CustList) item;
			System.out.println("...."+payload.getCustomer_ref());
		  
		}
		
	}

}
