package com.vzw.cst.listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.stereotype.Component;

@Component
public class FutureOrderExecuteListener implements JobExecutionListener {

	private static final Logger log = LoggerFactory.getLogger(FutureOrderExecuteListener.class);

	@Override
	public void beforeJob(JobExecution jobExecution) {
		// TODO Auto-generated method stub
		log.info("Job Parameters  {}", jobExecution.getJobParameters());
		log.info("Job  id  : {}  # start time : {} ", jobExecution.getJobId(), jobExecution.getStartTime());
	}

	@Override
	public void afterJob(JobExecution jobExecution) {
		// TODO Auto-generated method stub
		log.info("Job  id  : {}  # end time : {} ", jobExecution.getJobId(), jobExecution.getStartTime());
	}

}
