package com.vzw.cst.config;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

@Configuration
@EnableScheduling
public class SchedulerConfig {

	@Autowired
	JobLauncherConfig myJobLauncher;
	
	/*@Autowired
	Job myJob;
	
	@Autowired
	Job myJob2;*/

	SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");

	//@Scheduled(fixedRate = 5000)
	public void scheduleByFixedRate(){
		Map<String,Object> jobNames = new HashMap<>();
		/*jobNames.put("job1", myJob);
		jobNames.put("job2", myJob2);*/
		
		jobNames.put("job1", "myJob");
		jobNames.put("job2", "myJob2");
		
		myJobLauncher.trigger(jobNames);
	}
	
	@Scheduled(cron="*/160 * * * * ?")
	public void jobScheduler2trigger() throws Exception{
		
		myJobLauncher.trigger("samplejdbcJob1");
        System.out.println("batch2 started");
	}
	
	@Scheduled(cron="*/160 * * * * ?")
	public void jobScheduler2trigger1() throws Exception{
		
		myJobLauncher.trigger("samplejdbcJob1");
        System.out.println("batch2 started");
	}
}