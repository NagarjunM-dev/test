package com.vzw.cst.job.simplejdbc;

import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import com.vzw.cst.common.CustList;


@StepScope
@Configuration
public class SimpleJdbcItemReader {
	

	@Value("${fetch.size:1000}")
	public int fetchSize;

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	
	@StepScope
	@Bean(name = "customeJdbcCursorItemReader", destroyMethod = "")
	public JdbcCursorItemReader<CustList> customeJdbcCursorItemReader() {

		JdbcCursorItemReader<CustList> databaseReader = new JdbcCursorItemReader<>();
		databaseReader.setDataSource(jdbcTemplate.getDataSource());
		databaseReader.setSql("select customer_ref,feature_code,start_date from CUSTOMER_FEATURE_PTMP");
		databaseReader.setFetchSize(fetchSize);
		databaseReader.setRowMapper(new BeanPropertyRowMapper<>(CustList.class));
		return databaseReader;
	}
	
	

}
