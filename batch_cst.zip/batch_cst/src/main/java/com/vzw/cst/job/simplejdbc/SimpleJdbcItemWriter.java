package com.vzw.cst.job.simplejdbc;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.transform.BeanWrapperFieldExtractor;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzw.cst.common.CustList;

@StepScope
@Component
public class SimpleJdbcItemWriter implements ItemWriter<Object> {

	private static final Logger log = LoggerFactory.getLogger(SimpleJdbcItemWriter.class);



	@Override
	public void write(List<? extends Object> items) throws Exception {
		// TODO Auto-generated method stub
		List<CustList> lstBatchEntry = new ArrayList<>();
		ObjectMapper obMapper = new ObjectMapper();
		/* FlatFileItemWriter<CustList> writer = new FlatFileItemWriter<CustList>();
		  writer.setResource(new FileSystemResource("classpath:feeds/outputData1"));
		    DelimitedLineAggregator<CustList> aggregator= new DelimitedLineAggregator<>();
		    BeanWrapperFieldExtractor<CustList> fieldExtractor = new BeanWrapperFieldExtractor<CustList>();
		    fieldExtractor.setNames(new String[] {"customer_ref", "feature_code", "start_date"});

			   aggregator.setFieldExtractor(fieldExtractor);
			   writer.setLineAggregator(aggregator);*/
		    
		for (Object item : items) {
			CustList payload = (CustList) item;
			System.out.println(payload.getCustomer_ref());
		     
			    //Set output file location
			  

	}
	}
	
	
}
