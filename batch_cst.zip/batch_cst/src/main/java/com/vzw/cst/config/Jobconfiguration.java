/*package com.vzw.cst.config;

import java.util.Properties;


import org.springframework.batch.core.configuration.JobRegistry;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.support.JobRegistryBeanPostProcessor;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.SimpleJobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.repository.support.JobRepositoryFactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskExecutor;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.interceptor.TransactionProxyFactoryBean;


import javax.sql.DataSource;

@Configuration
@EnableBatchProcessing
public class Jobconfiguration {

	@Autowired
	PlatformTransactionManager platformTransactionManager;
	
	
	@Autowired
	JobRegistry jobRegistry;
	
	@Value("${maxPoolSize:400}")
	private int maxPoolSize;
	@Value("${corePoolSize:50}")
	private int corePoolSize;

	@Value("${threadKeepAliveSeconds:600}")
	private int threadKeepAliveSeconds;
	
	@Bean(name="DriverManagerDataSource")
	@ConfigurationProperties("spring.datasource")
	public DriverManagerDataSource dataSource(){
		return new DriverManagerDataSource();
	}
	
	@Autowired
	private DataSource dataSource;
	
	@Bean
	public TransactionProxyFactoryBean baseProxy() throws Exception {
		TransactionProxyFactoryBean transactionProxyFactoryBean = new TransactionProxyFactoryBean();
		Properties transactionAttributes = new Properties();
		transactionAttributes.setProperty("*", "PROPAGATION_REQUIRED");
		transactionProxyFactoryBean.setTransactionAttributes(transactionAttributes);
		transactionProxyFactoryBean.setTarget(getJobRepository());
		transactionProxyFactoryBean.setTransactionManager(platformTransactionManager);
		return transactionProxyFactoryBean;
	}
	
	
	public JobRepository getJobRepository() throws Exception {
	        JobRepositoryFactoryBean factory = new JobRepositoryFactoryBean();
	        factory.setDataSource(this.dataSource);
	        factory.setTransactionManager(platformTransactionManager);
	        factory.setIsolationLevelForCreate("ISOLATION_REPEATABLE_READ");
	        factory.setTablePrefix("BATCH_");
	        //factory.setMaxVarCharLength(1000);
	        factory.afterPropertiesSet();
	        return  factory.getObject();
	 }
	
	@Bean(name = "simpleJobLauncher")
	public JobLauncher simpleJobLauncher() throws Exception {
	    SimpleJobLauncher jobLauncher = new SimpleJobLauncher();
	     jobLauncher.setTaskExecutor(threadPoolTaskExecutor());
	     jobLauncher.setJobRepository(getJobRepository());
	    jobLauncher.afterPropertiesSet();
	    
	    return jobLauncher;
	}
	
	 @Bean(name = "threadPoolTaskExecutorJobLunch")
	  public TaskExecutor threadPoolTaskExecutor() {
		 ThreadPoolTaskExecutor threadPoolTaskExecutor = new ThreadPoolTaskExecutor();
		 threadPoolTaskExecutor.setCorePoolSize(corePoolSize);
		 threadPoolTaskExecutor.setMaxPoolSize(maxPoolSize);
		 threadPoolTaskExecutor.setAllowCoreThreadTimeOut(true);
		 threadPoolTaskExecutor.setThreadNamePrefix("batch_job_start_thread");
		 threadPoolTaskExecutor.setKeepAliveSeconds(threadKeepAliveSeconds);
	     return threadPoolTaskExecutor;
	    }
	

	@Bean
	public JobRegistryBeanPostProcessor JobRegistryBeanPostProcessor() {
		
		JobRegistryBeanPostProcessor jobRegistryBeanPostProcessor = new JobRegistryBeanPostProcessor();
		jobRegistryBeanPostProcessor.setJobRegistry(jobRegistry);
		return jobRegistryBeanPostProcessor;
		
		
	}
}
*/