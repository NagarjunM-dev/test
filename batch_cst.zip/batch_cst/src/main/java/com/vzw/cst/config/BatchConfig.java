package com.vzw.cst.config;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import javax.sql.DataSource;

import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.JobRegistry;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.configuration.support.JobRegistryBeanPostProcessor;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.launch.support.SimpleJobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.MultiResourceItemReader;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.BeanWrapperFieldExtractor;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.vzw.cst.common.CustList;
import com.vzw.cst.common.ReverseCheckBkDetails;
import com.vzw.cst.job.JobProcessor;
import com.vzw.cst.job.JobReader;
import com.vzw.cst.job.JobWriter;
import com.vzw.cst.job.sample.ConsoleItemWriter;
import com.vzw.cst.job.simplejdbc.FutureOrderItemWriter;
import com.vzw.cst.job.simplejdbc.SimpleJdbcItemWriter;
import com.vzw.cst.listener.FutureOrderExecuteListener;
import com.vzw.cst.listener.JobCompletionListener;
import com.vzw.cst.util.Item;

@Configuration
@EnableBatchProcessing
public class BatchConfig {

	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;

	@Autowired
	private DataSource dataSource;

	@Value("inputFiles/*.txt")
	private Resource[] inputResources;

	/*
	 * @Autowired JdbcTemplate jdbcTemplate;
	 */

	@Autowired
	@Qualifier("customeJdbcCursorItemReader")
	@StepScope
	JdbcCursorItemReader<CustList> customeJdbcCursorItemReader;

	@Autowired
	FutureOrderExecuteListener futureOrderExecuteListener;

	@Bean
	public JobRegistryBeanPostProcessor jobRegistryBeanPostProcessor(JobRegistry jobRegistry) {
		final JobRegistryBeanPostProcessor answer = new JobRegistryBeanPostProcessor();
		answer.setJobRegistry(jobRegistry);
		return answer;
	}

//////////////////////////////Job 2 related - Ends

//////////////////////////////// Job 2 related - Starts	  
	@Bean
	public ItemReader<Item> jobReader() {
		return new JobReader(new Item("1000", LocalDate.now()));
	}

	@Bean
	public ItemProcessor<Item, Item> jobProcessor() {
		return new JobProcessor();
	}

	@Bean
	public ItemWriter<Item> jobWriter() {
		return new JobWriter();
	}

	@Bean
	public Step getMyJobStep2() {
		return this.stepBuilderFactory.get("myJobStep2").<Item, Item>chunk(1).reader(jobReader())
				.processor(jobProcessor()).writer(jobWriter()).build();
	}

	@Bean("myJob2")
	public Job myJob2() {
		return jobBuilderFactory.get("myJob2").listener(new JobExecutionListener() {
			@Override
			public void beforeJob(JobExecution jobExecution) {
				System.out.println("Ready to start the job2");
			}

			@Override
			public void afterJob(JobExecution jobExecution) {
				if (jobExecution.getStatus() == BatchStatus.COMPLETED) {
					System.out.println("Job2 successfully executed with " + jobExecution.getStatus());
				} else if (jobExecution.getStatus() == BatchStatus.FAILED) {
					System.out.println("Job2 Failed executed with " + jobExecution.getStatus());
				}
			}
		}).incrementer(new RunIdIncrementer()).start(getMyJobStep2()).build();
	}
//////////////////////////////Job 2 related - Ends

	@Bean
	public Job job() {
		Job job = jobBuilderFactory.get("job").incrementer(new RunIdIncrementer()).listener(listener()).flow(step())
				.end().build();
		return job;
	}

	@Bean
	public Step step() {
		Step step = stepBuilderFactory.get("step").<String, String>chunk(1).reader(new com.vzw.cst.job.sample.Reader())
				.processor(new com.vzw.cst.job.sample.Processor()).writer(new com.vzw.cst.job.sample.Writer()).build();
		return step;
	}

	@Bean
	public JobExecutionListener listener() {
		return new JobCompletionListener();
	}

	@Bean(name = "samplejdbcJob")
	public Job samplejdbcJob() {
		return jobBuilderFactory.get("samplejdbcJob").incrementer(new RunIdIncrementer()).listener(listener())
				.start(stepExcute()).build();
	}

	@Bean
	public Step stepExcute() {
		return stepBuilderFactory.get("stepExcute").chunk(1).reader(customeJdbcCursorItemReader).writer(writertager())
				.listener(listener()).build();
	}
	  
	private ItemReader<? extends Object> fileReader() {
		// TODO Auto-generated method stub
		return null;
	}

	@StepScope
	@Bean
	public ItemWriter<? super Object> writertager1() {
		return new SimpleJdbcItemWriter();
	}

	@StepScope
	@Bean
	public ItemWriter<? super Object> writertager() {
		return new FutureOrderItemWriter();
	}

	// DB to csv

	@Bean
	public JdbcCursorItemReader<CustList> jdbcReader() {
		JdbcCursorItemReader<CustList> jdbcReader = new JdbcCursorItemReader<CustList>();
		jdbcReader.setSql("select customer_ref,feature_code,start_date from CUSTOMER_FEATURE_PTMP");

		jdbcReader.setDataSource(dataSource);
		jdbcReader.setRowMapper(new RowMapper<CustList>() {

			@Override
			public CustList mapRow(ResultSet rs, int rowNum) throws SQLException {
				CustList custList = new CustList();
				custList.setCustomer_ref(rs.getString("Customer_ref"));
				custList.setFeature_code(rs.getString("Feature_code"));
				custList.setStart_date(rs.getDate("start_date"));
				return custList;
			}
		});
		return jdbcReader;

	}

	@Bean
	public FlatFileItemWriter<CustList> dbToFilewriter() {
		// Create writer instance
		FlatFileItemWriter<CustList> writer = new FlatFileItemWriter<CustList>();

		// Set output file location
		writer.setResource(new FileSystemResource("feeds/FEED2"));
		DelimitedLineAggregator<CustList> aggregator = new DelimitedLineAggregator<>();
		BeanWrapperFieldExtractor<CustList> fieldExtractor = new BeanWrapperFieldExtractor<CustList>();
		fieldExtractor.setNames(new String[] { "customer_ref", "feature_code", "start_date" });
		aggregator.setFieldExtractor(fieldExtractor);
		writer.setLineAggregator(aggregator);
		System.out.println("writing to file2");
		return writer;
	}

	@Order(2)
	@Bean("samplejdbcJob1")
	// @Scheduled(cron="*/10 * * * * ?")
	public Job dbToCsvJob() {
		System.out.println("samplejdbcJob1");
		return jobBuilderFactory.get("samplejdbcJob1").flow(dbToCsvStep()).end().listener(listener()).build();
	}

	@Bean
	public Step dbToCsvStep() {
		return stepBuilderFactory.get("dbToCsvStep").<CustList, CustList>chunk(5).reader(jdbcReader())
				.writer(dbToFilewriter()).allowStartIfComplete(true).build();
	}

	@Bean(name = "LiveOrderProcessMultiJobs")
	public Job liveJobMultipleJob() {
		return jobBuilderFactory.get("LiveOrderProcessMultiJobs").incrementer(new RunIdIncrementer())
				.listener(listener()).start(stepExcute()).build();
	}

	@Bean("customTaskExecutor")
	public ThreadPoolTaskExecutor taskExecutor() {
		ThreadPoolTaskExecutor taskExecutor = new ThreadPoolTaskExecutor();
		taskExecutor.setCorePoolSize(15);
		taskExecutor.setMaxPoolSize(20);
		taskExecutor.setQueueCapacity(30);
		return taskExecutor;
	}

	@Bean("customJobLauncher")
	public JobLauncher jobLauncher(JobRepository jobRepository) {
		SimpleJobLauncher sjl = new SimpleJobLauncher();
		sjl.setJobRepository(jobRepository);
		sjl.setTaskExecutor(taskExecutor());

		System.out.println("customJobLauncher----");

		return sjl;
	}
	// ----------------------------

	@Bean(name = "genericJob1")
	public Job genericJob1() {
		return jobBuilderFactory.get("genericJob1").incrementer(new RunIdIncrementer())
				.listener(futureOrderExecuteListener).start(stepExcute()).build();
	}

	@Bean(name = "sampleReadJob")
	public Job jobStrater() {
		System.out.println(">>>>>>>File Reader Job Started<<<<<<<");
		return jobBuilderFactory.get("sampleReadJob").incrementer(new RunIdIncrementer()).listener(listener())
				.flow(fileToList()).end().build();
	}

	@Bean
	public Step fileToList() {
		System.out.println("fileToList  is called ");
		return stepBuilderFactory.get("fileToList").<ReverseCheckBkDetails, ReverseCheckBkDetails>chunk(5)
				.reader(multiResourceItemReader())
				.writer(writer())
				.build();
	}

	@Bean
	public MultiResourceItemReader<ReverseCheckBkDetails> multiResourceItemReader() {
  
		MultiResourceItemReader<ReverseCheckBkDetails> resourceItemReader = new MultiResourceItemReader<ReverseCheckBkDetails>();
		resourceItemReader.setResources(inputResources);
		resourceItemReader.setDelegate(reader());
		return resourceItemReader;
	}

	@Bean
	public FlatFileItemReader<ReverseCheckBkDetails> reader() {

		FlatFileItemReader<ReverseCheckBkDetails> reader = new FlatFileItemReader<ReverseCheckBkDetails>();

		// Create reader instance

//		// Set number of lines to skips. Use it if file has header rows.
//		reader.setLinesToSkip(1);

		// Configure how each line will be parsed and mapped to different values
		reader.setLineMapper(new DefaultLineMapper() {
			{
				setLineTokenizer(new DelimitedLineTokenizer() {
					{
						setNames(new String[] { "Card_Offer_Trk_No", "Cust_id_no", "Acct_no","Mtn","Disconn_chargebck_Ts","Vis_Instance" });
					}
				});
				setFieldSetMapper(new BeanWrapperFieldSetMapper<ReverseCheckBkDetails>() {
					{
						setTargetType(ReverseCheckBkDetails.class);
					}
				});
			}
		});
		return reader;
	}
	
	@Bean
  public ConsoleItemWriter<ReverseCheckBkDetails> writer() 
  {
    return new ConsoleItemWriter<ReverseCheckBkDetails>();
  }

}
