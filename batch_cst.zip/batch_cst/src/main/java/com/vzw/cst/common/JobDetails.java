package com.vzw.cst.common;

import java.util.List;

public class JobDetails {
	
	/*    name: sample1
    cronValue: 
    files:
      -
      location: classpath:feeds/
     /* name: inputfile
      format: customer,6|mtn,10*/
	
	String name;
	String cronValue;
	List<FileDetails> files;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCronValue() {
		return cronValue;
	}
	public void setCronValue(String cronValue) {
		this.cronValue = cronValue;
	}
	public List<FileDetails> getFiles() {
		return files;
	}
	public void setFiles(List<FileDetails> files) {
		this.files = files;
	}
	
	
	
	

}
