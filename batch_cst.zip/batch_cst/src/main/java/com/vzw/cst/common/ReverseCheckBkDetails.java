package com.vzw.cst.common;

import java.util.Date;

public class ReverseCheckBkDetails {
	private int Card_Offer_Trk_No;
	private int Cust_id_no;
	private int Acct_no;
	private int Mtn;
	private Date Disconn_chargebck_Ts;
	private String Vis_Instance;
	
	public int getCard_Offer_Trk_No() {
		return Card_Offer_Trk_No;
	}
	public void setCard_Offer_Trk_No(int card_Offer_Trk_No) {
		Card_Offer_Trk_No = card_Offer_Trk_No;
	}
	public int getCust_id_no() {
		return Cust_id_no;
	}
	public void setCust_id_no(int cust_id_no) {
		Cust_id_no = cust_id_no;
	}
	public int getAcct_no() {
		return Acct_no;
	}
	public void setAcct_no(int acct_no) {
		Acct_no = acct_no;
	}
	public int getMtn() {
		return Mtn;
	}
	public void setMtn(int mtn) {
		Mtn = mtn;
	}
	public Date getDisconn_chargebck_Ts() {
		return Disconn_chargebck_Ts;
	}
	public void setDisconn_chargebck_Ts(Date disconn_chargebck_Ts) {
		Disconn_chargebck_Ts = disconn_chargebck_Ts;
	}
	public String getVis_Instance() {
		return Vis_Instance;
	}
	public void setVis_Instance(String vis_Instance) {
		Vis_Instance = vis_Instance;
	}
	@Override
	public String toString() {
		return "ReverseCheckBkDetails [Card_Offer_Trk_No=" + Card_Offer_Trk_No + ", Cust_id_no=" + Cust_id_no
				+ ", Acct_no=" + Acct_no + ", Mtn=" + Mtn + ", Disconn_chargebck_Ts=" + Disconn_chargebck_Ts
				+ ", Vis_Instance=" + Vis_Instance + "]";
	}
	
	
	
	}
