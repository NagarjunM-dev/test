package com.vzw.cst.util;

import java.util.List;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import com.vzw.cst.common.JobDetails;

@Configuration
@ConfigurationProperties(prefix="cst")
@EnableConfigurationProperties
public class JobDetailConfig {

	
	 private List<JobDetails> jobs;

	public List<JobDetails> getJobs() {
		return jobs;
	}

	public void setJobs(List<JobDetails> jobs) {
		this.jobs = jobs;
	}
	 
	 

}
