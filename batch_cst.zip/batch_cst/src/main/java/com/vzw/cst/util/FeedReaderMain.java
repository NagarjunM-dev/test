package com.vzw.cst.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStream;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.springframework.util.ResourceUtils;

public class FeedReaderMain {
	private static String mySubString(String myString, int start, int length) { 
	      return myString.substring(start, Math.min(start + length, myString.length()));
		}
	
	public static void main(String[] args) {
		Properties mainProperties = loadProps(); 
		String feedName="FEED1";
		List<Map<String,String>> list =feedReader(feedName);
		
		
	    System.out.println(list);
		fetchOutputFeed(list ,feedName);
		
		

	}
	
	private static List<Map<String,String>> feedReader(String feedName) {
		Properties mainProperties = loadProps(); 
		String fileName=mainProperties.getProperty(feedName+".NAME"); 
		String fileLocation=mainProperties.getProperty(feedName+".location"); 
		String delimeter=mainProperties.getProperty(feedName+".delemit"); 
		String desc=mainProperties.getProperty(feedName+".Desc"); 
		List<Map<String,String>> list=new LinkedList<>(); 
		
		try { 
		File file=ResourceUtils.getFile(fileLocation+fileName); 
		BufferedReader br=new BufferedReader(new FileReader(file)); 
		String strLine;
		
		String[] str = desc.split(","); 
		
		LinkedHashMap<String, Integer> desclist = new LinkedHashMap<>();
		
		if(delimeter.trim().equals("fixedlength")) {
			for (int i = 0; i < str.length; i++) { 
				System.out.println(str[i]); 
				String[] strArray = str[i].split("\\|"); 
				desclist.put(strArray[0], Integer.parseInt(strArray[1].trim())); 
			}
		}
		System.out.println(desclist);
		int customerLength=0;
		while ((strLine=br.readLine())!= null) { 
			   int index=0;
			   Map<String,String> map=new LinkedHashMap<>(); 
			   if(delimeter.trim().equals("fixedlength")) {
				     for(Map.Entry<String, Integer> entry : desclist.entrySet()) {
				    	 if(index==0) {
				    		 map.put(entry.getKey(), strLine.substring(0, entry.getValue()));
				    		 customerLength=entry.getValue();
				    	 } else {
				    		 map.put(entry.getKey(),mySubString(strLine,customerLength,entry.getValue()) );
				    		 customerLength=entry.getValue();
				    	 }
				    	 index++;
				     }

			   } else{
					   String[] arrayOfFeeds=strLine.split(",");
					   for(int i=0;i<arrayOfFeeds.length;i++) {
					   map.put("customerId", arrayOfFeeds[i]);
				   }
			   }
				   list.add(map);
				   
			   }
		}catch (Exception e) {
			// TODO: handle exception
		}
		return list;
	}

	private static Properties loadProps() {
		Properties mainProperties = new Properties(); 
		try { 
		//File parentFile = new File("feedReader.properties"); 
		String path = "feedReader.properties"; 
		//String path = "/reporting.properties"; 
		File file = ResourceUtils.getFile("classpath:feeds/"+path); 
		InputStream in = new FileInputStream(file); 
		mainProperties.load(in); 
		}catch (Exception e) { 
		System.out.println("E"+e); 
		} 
		
		return mainProperties; 
	}
	
	public static void fetchOutputFeed(List<Map<String, String>> list,String feedName) { 
		// TODO Auto-generated method stub 
		try {
			Properties mainProperties = loadProps(); 
			String outputFileName=mainProperties.getProperty(feedName+".OUTPUTFILE"); 
			String outputFileLocation=mainProperties.getProperty(feedName+".OUTPUTFILELOCATION"); 
			String outputFileDesc = mainProperties.getProperty(feedName+".outputfiledesc");  
			
			LinkedHashMap<String, Integer> outputFileDecsmap = new LinkedHashMap<>();
			String[] outFileDescArray = outputFileDesc.split(",");
			
			
			for (int i = 0; i < outFileDescArray.length; i++) { 
				System.out.println(outFileDescArray[i]); 
				String[] strArray = outFileDescArray[i].split("\\|"); 
				outputFileDecsmap.put(strArray[0], Integer.parseInt(strArray[1].trim())); 
				}
			File file=ResourceUtils.getFile(outputFileLocation+outputFileName); 
			BufferedWriter writer = new BufferedWriter(new FileWriter(file)); 
			for (int i = 0; i < list.size(); i++) {				
				 for(Map.Entry<String, Integer> entryoutput :outputFileDecsmap.entrySet()) {
					 for(Map.Entry<String, String> entry:list.get(i).entrySet()) {
						 if(entry.getKey().equals(entryoutput.getKey())) {
							 writer.write(entry.getKey()+"="+list.get(i).get(entry.getKey()));
							 writer.write(" ");
						 } 
					 }
					 
				 }
				writer.write("\r\n");
				 writer.flush();
			}
			 writer.flush(); 
			 System.out.println("File writed succesfully"); 
			} catch (Exception e) { 
				// TODO: handle exception
				e.printStackTrace(); 
				} 
		}
	
}
	

	 
