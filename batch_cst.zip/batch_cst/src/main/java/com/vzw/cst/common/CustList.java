package com.vzw.cst.common;

import java.util.Date;

public class CustList {
	String customer_ref;
	  String feature_code;
	  Date start_date;
	  
	  
	  
	  
	public CustList() {
		
	}
	public CustList(String customer_ref, String feature_code, Date start_date) {
		super();
		this.customer_ref = customer_ref;
		this.feature_code = feature_code;
		this.start_date = start_date;
	}
	public String getCustomer_ref() {
		return customer_ref;
	}
	public void setCustomer_ref(String customer_ref) {
		this.customer_ref = customer_ref;
	}
	public String getFeature_code() {
		return feature_code;
	}
	public void setFeature_code(String feature_code) {
		this.feature_code = feature_code;
	}
	public Date getStart_date() {
		return start_date;
	}
	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}
	  
	  
}
