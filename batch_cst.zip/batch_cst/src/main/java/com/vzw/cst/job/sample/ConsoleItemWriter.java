package com.vzw.cst.job.sample;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import org.springframework.batch.item.ItemWriter;
 
public class ConsoleItemWriter<T> implements ItemWriter<T> {

	@Override
	public void write(List<? extends T> items) throws Exception {
		// TODO Auto-generated method stub
		List<HashMap<String,String>> list=new LinkedList<>();
		HashMap<String, String> map=new HashMap<String,String>();
		
		if(items.size()!=0 && items!=null) {
			for(T item:items) {
				//map.put(item, value);
				
			}
				
			
		}
			
	}
	
}
