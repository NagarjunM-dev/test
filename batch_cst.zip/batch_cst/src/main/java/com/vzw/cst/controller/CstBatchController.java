package com.vzw.cst.controller;



import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzw.cst.common.JobDetails;
import com.vzw.cst.config.JobLauncherConfig;
import com.vzw.cst.util.JobDetailConfig;

@RestController
public class CstBatchController {

	@Autowired
	JobLauncherConfig myJobLauncher;
	
	@Autowired
	JobDetailConfig jobDetailsConfig;
	
	
	
	@GetMapping("/trigger/job/{jobName}")
	public String triggerJobName(@PathVariable String jobName) {
		List<JobDetails> jobList=jobDetailsConfig.getJobs().stream().filter(e-> e.getName().equals(jobName)).collect(Collectors.toList());
		if(jobList.size()==1) {
		JobExecution je = myJobLauncher.trigger(jobName);
		return "hello >> " + je.getStatus().toString() + "Job Name >>" + jobName;
		}
		
		return "hello >>  Job Name >>" + jobName +"is not valid";
	}
	
	@GetMapping("/trigger/jobs")
	public String triggerJobs(@RequestParam String jobName) {
		List<JobExecution> jobExecutionList= new ArrayList<>();
		String[] jobArray=jobName.split(",");
		System.out.println(jobDetailsConfig.getJobs());
		Arrays.asList(jobArray).parallelStream().forEach( 
				e->  
				{
					jobExecutionList.add(myJobLauncher.trigger(e));
					
				}
				);
		//JobExecution je = myJobLauncher.trigger(jobName);
		return "hello1 >> " + jobName;
	}
	
	@GetMapping("getJobDetails")
	public String getJobDetails() throws JsonProcessingException {
		return new ObjectMapper().writeValueAsString(jobDetailsConfig.getJobs());
	}
	
}
