package com.vzw.cst.util;

import java.util.Map;

public class DomainObject {

	private Map<String,Object> text;

	public Map<String, Object> getText() {
		return text;
	}

	public void setText(Map<String, Object> text) {
		this.text = text;
	}

	@Override
	public String toString() {
		return "["+text+"]";
	}

	
	
}
