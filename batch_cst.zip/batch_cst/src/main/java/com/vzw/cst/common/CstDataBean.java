package com.vzw.cst.common;

import java.util.List;
import java.util.Map;

public class CstDataBean {
	
	List<Map<String,String>> data;
	
	JobDetails jobDetails;

	public List<Map<String, String>> getData() {
		return data;
	}

	public void setData(List<Map<String, String>> data) {
		this.data = data;
	}

	public JobDetails getJobDetails() {
		return jobDetails;
	}

	public void setJobDetails(JobDetails jobDetails) {
		this.jobDetails = jobDetails;
	}
	
	
	

}
