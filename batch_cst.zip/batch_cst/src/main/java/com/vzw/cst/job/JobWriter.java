package com.vzw.cst.job;

import java.util.List;

import org.springframework.batch.item.ItemWriter;

import com.vzw.cst.util.Item;

public class JobWriter implements ItemWriter<Item> {

	@Override
	public void write(List<? extends Item> items) throws Exception {
		System.out.println("Job Writer");
		
	}

}
