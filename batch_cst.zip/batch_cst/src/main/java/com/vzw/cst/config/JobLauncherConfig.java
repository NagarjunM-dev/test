package com.vzw.cst.config;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Map;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.configuration.JobRegistry;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.NoSuchJobException;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class JobLauncherConfig {

	//@Autowired
	//@Qualifier("simpleJobLauncher")
	//JobLauncher jobLauncher;

	@Autowired
	@Qualifier("customJobLauncher")
	JobLauncher jobLauncher;
	
	@Autowired
	JobRegistry jobRegistry;

	public JobExecution trigger(Object jobNames) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
		String jobName = null;
		if (jobNames instanceof Map) {
			// jobName = ((Map) jobNames).get("job1");
			jobName = (String) ((Map) jobNames).get("job2");
		} else {
			jobName = (String) jobNames;
		}
		
		System.out.println("Batch job starting >> Jobnames" + jobNames);

		JobParametersBuilder jpBuilder = new JobParametersBuilder();
		JobParameters jobParameters = jpBuilder.addString("time", format.format(Calendar.getInstance().getTime()))
				.toJobParameters();
		JobExecution je = null;
		try {
				Job job = (Job) jobRegistry.getJob(jobName);
				
				je = jobLauncher.run(job, jobParameters);
		} catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException
				| JobParametersInvalidException | NoSuchJobException e) {
			e.printStackTrace();
		}
		System.out.println("Batch job executed successfully\n");
		
		return je;
	}	
	
}
