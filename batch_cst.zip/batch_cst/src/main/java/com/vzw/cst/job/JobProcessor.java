package com.vzw.cst.job;

import org.springframework.batch.item.ItemProcessor;

import com.vzw.cst.util.Item;

public class JobProcessor implements ItemProcessor<Item, Item> {

	@Override
	public Item process(Item item) throws Exception {
		System.out.println("JobProcessor::process() -> item: " + item);

		Item model = new Item();
		model.setId(item.getId());
		model.setDate(item.getDate());

		return model;
	}

}
