package com.vzw.cst.common;

public class FileDetails {
	
	/* -
     location: classpath:feeds/
     name: inputfile
     format: customer,6|mtn,10*/
	String name;
	String location;
	String format;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getFormat() {
		return format;
	}
	public void setFormat(String format) {
		this.format = format;
	}
	
	
	

}
